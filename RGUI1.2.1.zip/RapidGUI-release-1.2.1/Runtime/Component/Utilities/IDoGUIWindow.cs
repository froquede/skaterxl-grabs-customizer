﻿using System;

namespace RapidGUI
{
    public interface IDoGUIWindow
    {
        void DoGUIWindow();
        void CloseWindow();
    }
}