﻿namespace RapidGUI
{
    /// <summary>
    /// DoGUI interface
    /// </summary>
    public interface IDoGUI
    {
        void DoGUI();
    }
}